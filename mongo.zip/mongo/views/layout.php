<!doctype html>
<html>
<head>
	<title>Blog php and Mongo</title>
	<link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.0/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="<?php echo URL;?>/static/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo URL ;?>/static/css/styles.css">
	
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> 
	<script src="<?php echo URL;?>/static/js/bootstrap.min.js"></script>

</head>
<body>
	<div class="container">
		
		<div class="row">
			
		<?php include_once ($path); ?>
	    
	    </div>
	</div>

</body>
</html>