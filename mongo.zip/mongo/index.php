<?php 
Class db {

   const dbUser = "root";
   const dbPass = "";
   const dbName = "databasename";

   private static $instance;
   private static $dbs;
   private function __construct() { } 
   public static function conn()
    {
        try
        {
            $mongo = new Mongo("mongodb://".self::dbUser.":".self::dbPass."@localhost/".self::dbName."");
            self::$dbs = $mongo->selectDB(self::dbName);
            self::$instance = new db(); 
        }
        catch(MongoConnectionException $e)
        {  
            die('Connection Failed' );
        }
        return self::$instance;
    }


    public function selectDocument($collectionName, $fields = array(), $where = array(), $sort = array(), $limit = 0)
    { 
        $cur = self::$dbs->$collectionName->find($where, $fields)->limit($limit);
        $cur->sort($sort);

        $this->docs = null; 
        while( $docs = $cur->getNext())
        {
        $this->docs[] = $docs;  
        }
        return $this->docs;
    }

    public function insertDocument($obj, $collectionName)
    {
        $collection = self::$dbs->$collectionName;
        try{
            $collection->insert($obj, array('w'=>true) );
            return  ( !empty($obj['_id']) )?1:0;
        } catch (MongoException $e) {
            return "Can't insert!n";
        }      
    }    

    public function updateDocument($collectionName, $criteria, $update, $confirm)
    {    

        $collection = self::$dbs->$collectionName;
        try
        {
            $collection->update($criteria,$update, array("multiple" => true));
            $num_rows = $collection->find($confirm)->count();
            return ( !empty($num_rows) )?$num_rows:0;
        } catch (MongoException $e) {
            return "Can't update!n";
        }         
    }    

    public function removeDocument($collectionName, $criteria)
    {    

        $collection = self::$dbs->$collectionName;
        try
        {
            $collection->remove($criteria);
            $num_rows = $collection->find($criteria)->count();
            return ( empty($num_rows) )?1:0;
        } catch (MongoException $e) {
            return "Can't update!n";
        }        
    }        

}

/* INSERT RECORDS */
$obj = array('first_name'=>'Dennis','last_name'=>'Crowley','title'=>'Mayor');
$collectionName = 'user';
$retVals = db::conn()->insertDocument($obj, $collectionName);

/* SELECT RECORDS */
$collectionName = 'user';
$fields        = array('first_name' => 1,'last_name' => 1,'title' => 1);
$where      = array('title'=>'mayor');      
$sort          = array('_id'=>1);
$limit          = 1;
$retVals = db::conn()->selectDocument($collectionName, $fields, $where, $sort, $limit);

/* UPDATE RECORDS */
/* The confirm param kind of lets me know that the document was updated */
$collectionName = 'user';
$criteria   = array('first_name'=>'Dennis','last_name'=>'Crowley');
$update   = array('$set' => array('title'=>'CEO') ); 
$confirm  = array('first_name'=>'Dennis','last_name'=>'Crowley','title'=>'CEO');
$retVals   = db::conn()->updateDocument($collectionName, $criteria, $update, $confirm);

/* DELETE RECORDS */
$collectionName = 'user';
$criteria  = array('first_name'=>'Dennis','last_name'=>'Crowley');
$retVals  = db::conn()->removeDocument($collectionName, $criteria);

?>